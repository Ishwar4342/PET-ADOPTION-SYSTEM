package com.straypartadoption;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StrayPartAdoptionApplication {

	public static void main(String[] args) {
		SpringApplication.run(StrayPartAdoptionApplication.class, args);
	}

}
