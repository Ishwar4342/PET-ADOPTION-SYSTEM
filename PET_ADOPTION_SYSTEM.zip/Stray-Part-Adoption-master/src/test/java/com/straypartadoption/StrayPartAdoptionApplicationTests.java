package com.straypartadoption;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StrayPartAdoptionApplicationTests {

	@Test
	void contextLoads() {
	}

}
